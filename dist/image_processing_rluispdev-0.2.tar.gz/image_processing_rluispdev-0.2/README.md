# Project description

The package `image-processing-rluispdev` is used for:

## Processing:
- Histogram matching
- Structural similarity
- Image resizing

## Utils:
- Head image
- Save image
- Plot image
- Plot result
- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `image-processing-rluispdev`.

```bash
pip install image-processing-rluispdev

## Usage

### Funções Principais de Processamento de Imagem

#Para realizar operações de processamento de imagens, como comparação, redimensionamento e visualização, use os seguintes módulos:

#### Exemplo de código:

```python
from image_processing_rluispdev.combination import find_difference, transfer_histogram
from image_processing_rluispdev.transformation import resize_image
from image_processing_rluispdev.io import read_image, save_image
from image_processing_rluispdev.plot import plot_image

# Carregar duas imagens
image1 = read_image("path_to_image1.jpg")
image2 = read_image("path_to_image2.jpg")

# Comparar as imagens (similaridade estrutural)
difference_image = find_difference(image1, image2)

# Transferir o histograma de uma imagem para outra
matched_image = transfer_histogram(image1, image2)

# Redimensionar a imagem
resized_image = resize_image(image1, 0.5)

# Salvar a imagem processada
save_image(difference_image, "difference_image.jpg")

# Plotar a imagem original
plot_image(image1)

# Plotar imagens comparadas lado a lado com o resultado
plot_image(difference_image)

## Author
rluispdev

## License
[MIT](https://choosealicense.com/licenses/mit/)

